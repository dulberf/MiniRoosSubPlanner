# Sideline UI — design handoff

One document. Everything designed to date for the MiniRoos Sub Planner, including the work
already shipped on `ui/sideline-redesign`, the four new screens, and the corrections that
came out of reading `replan.js`.

**Design file:** `Sideline UI.dc.html` — a static HTML reference, not production code.
Sections read newest-first: **TURN 4** (4a, 4b) → **TURN 3** (3a–3d) → **TURN 2** (2a–2e,
already built) → TURN 1 explorations → the current app recreated for comparison.
Open it with `support.js` beside it, both included here.

**Every screen in this doc has a render.** `screens/` holds a PNG per frame at its design
size — 1024 × 1366 for the portrait screens, 1366 × 1024 for 4b. Nothing below is prose-only.

**Canvas:** every portrait frame is 1024 × 1366 (iPad portrait at 1×). The landscape frame
is 1366 × 1024. Keep drawing at those sizes; the existing `s(px)` helper in `useScale.js`
maps them onto the real device.

**Tokens:** `UI` in `src/constants.js`. Navy chrome, exactly three status colours
(`go` / `warn` / `stop`). Nothing in the chrome may compete with `POS_BG` — those are
physical wristbands on children's arms.

---

## Status

| Screen | State | Render | Repo target |
|---|---|---|---|
| 2a Live game | Built | `2a-live-game.png` | `TeamSheetView.jsx`, `FieldView.jsx` |
| 2b Player sheet | Built | `2b-player-answer.png` | `TeamSheetView.jsx` |
| 2c Honours | Built — **superseded by 4a** | `2c-honours.png` | `TeamSheetView.jsx` |
| 2d Save | Built | `2d-save.png` | `TeamSheetView.jsx` |
| 2e Season | Built | `2e-season.png` | `SeasonView.jsx` |
| 3a Match setup | To build | `3a-match-setup.png` | `InputView.jsx` — drop-in provided |
| 3b Squad sheet | To build | `3b-squad-sheet.png` | `TeamSheetView.jsx` squad sheet |
| 3c Player off | To build | `3c-player-off.png` | replaces the player-out modal |
| 3d Minutes prompt | To build | `3d-minutes-prompt.png` | replaces the `subPrompt` modal |
| 4a Honours | To build | `4a-honours.png` | replaces the 2c honours sheet |
| 4b Landscape | To build | `4b-live-game-landscape.png` | `TeamSheetView.jsx` layout branch |

Two states are specified in prose with **no render** and are called out as such where they
appear: the goalkeeper-cannot-be-marked-out block and the 6-player floor, both under 3c.

---

## 3a — Match setup

`InputView.jsx` here is a **drop-in replacement** with the same props and callbacks, plus one
new prop: `seasonGames` (the array App.jsx already holds — pass it through alongside
`seasonGameCount`).

### Three corrections applied since the last export

1. **GK ordering now uses `orderPlayersForGame`** (`scheduler.js:171`), which App.jsx already
   calls at `App.jsx:132` and `App.jsx:200`. The previous version re-derived GK history from
   `g.gkH1` / `g.gkH2` on saved games. **Those fields do not exist** — a saved game carries
   `{ date, label, players, segments, stats, goals, assists, potm, captain, ourScore,
   oppositionScore, result, notes }`, and GK history is recovered from `segment.half` plus
   `assignment.GK` (`scheduler.js:186-197`). The old sort was a silent no-op under a heading
   that promised fairness ordering. `result[0]` is the best H1 candidate,
   `result[getSecondGKSlot(n)]` the next-best; the chip row leads with those two.
2. **"Same as 1st half" needs an app-side fix to work.** The auto-suggest effect at
   `App.jsx:137-151` keeps a chosen `gkH2` only when `gkH2 !== finalH1`, so setting them
   equal is overwritten by the oracle on the next render. The same effect means clearing a
   selected GK chip snaps back to the oracle's pick. This is pre-existing — the old
   `<select>`'s "same as H1 — full game" option was clobbered identically — but the chip row
   makes it visible. **A full-50-minute keeper is not selectable until that effect allows
   `gkH2 === gkH1`. Ship that fix with this screen.**
3. **Text floors raised to 15 px.** The file previously floored at 11, 12 and 13 px, which on
   the coach's 810 px iPad (scale 0.79) rendered below the project minimum. All floors are
   now ≥ 15, all-caps labels only.

What changed and why:

- Navy header, `SEASON` / `IMPORT` as outlined buttons — same chrome as 2a.
- Roster toggles are navy-fill / white-outline chips with a tick. The ✅/❌ emoji pairing is
  gone: green-and-grey on every row made the squad count invisible.
- **The only status colour on the screen is the squad-count badge.** A short squad is
  therefore the one thing that catches the eye.
- **Both GK dropdowns become chip rows** — eligible-first, with an "Everyone else ▾"
  expander and a "Same as 1st half" chip. These were the last two `<select>`s in the app.
- The amber game-plan card becomes the **period-pip strip from the live screen** plus three
  fact tiles. Setup now rehearses the screen the coach stares at all game.

---

## 3b — Squad sheet

Replaces the invented "Squad & game" modal. It is a **right-hand side sheet, full height, 648
px wide**, over a `UI.scrim` backdrop — *not* a centred modal. The header and pip strip stay
visible and legible above it. Losing sight of the clock is the failure mode this whole
redesign exists to fix; a centred modal over a running game reintroduces it.

Structure, top to bottom:

1. **Header** — "Squad", live count line ("11 here · 9 on · 2 on the bench"), close ✕.
2. **WHO'S AVAILABLE** — a 3-column chip grid of the whole roster, one chip per player:
   - navy fill = playing, with position and `ON` underneath;
   - white with navy border = playing, on the bench, with `BENCH · ON AT 17`;
   - **dashed pale border = not here**.
   Tap a navy chip → 3c. Tap a dashed chip → bring them on. Plus a `+ SOMEONE NEW` dashed
   chip for a name not in the roster.
   **This deletes LATE PLAYER and PLAYER OUT as buttons, and both of their follow-up modals.**
   It also answers "who is actually here", which the old sheet never did.
3. **REARRANGE THE LINEUP** / **SHOW THE KIDS** — an equal pair, with a line underneath:
   "Moving one player is quicker from the pitch — tap them, then MOVE POSITION."
4. **MATCH NOTES** — low in the sheet. It is a half-time, standing-still task and must not
   compete for the thumb.
5. **START AGAIN** — below a rule, pinned to the bottom: `Restart this period` (ghost) and
   `Wipe the game` (red outline, **hold 2 seconds**). Reset is the only irreversible action
   in the app and it was sitting a thumb-width from the notes box.

### On the two routes to the emergency sub

Keep both, but stop them looking like the same button. The **fast path is the pitch** — tap
the player, then MOVE POSITION. One tap, and it is what a coach reaches for when a kid goes
down, because they are looking at the player and not at a menu. The sheet's route is the
**deliberate, several-players-at-once** path and is now named REARRANGE THE LINEUP. Different
names, different scopes. If telemetry or memory says nobody ever rearranges more than one
player, delete the sheet's copy and let the pitch own it outright.

---

## 3c — A player comes off

Expands **in place inside the sheet**. No second modal, no losing your scroll position.
Amber, not red: this changes the plan, it is not an error.

The panel, in order:

1. Title — "Grace comes off now".
2. "She keeps the **21 minutes** she has played. Nothing already played changes."
3. **WHO TAKES CENTRE MID NOW?** — bench chips, each labelled with minutes played, default
   selection on the lowest. This matches `pickReplacement()` in `replan.js`, which returns
   the bench player with the least cumulative minutes.
4. **WHAT THIS DOES TO THE REST** — white card, plain English:
   > Maddy goes straight into centre mid. The rest of this half and the whole second half
   > are then re-planned for 10 players, sharing the remaining minutes equally — so the
   > periods after this one will not match what's on the board now.

   This wording was corrected after reading `replan.js`. The removed player's minutes are
   **not** handed to one substitute: `buildRemainderForHalf` rebuilds the rest of the half,
   and an H1 removal also triggers `buildFreshHalf` for the whole second half. Telling the
   coach the future periods will change is the honest version, and it is the thing they will
   otherwise notice ten minutes later and distrust.
5. `Cancel` / `TAKE GRACE OFF`.

### Two states still to design, both already enforced in `replan.js`

- **The goalkeeper cannot be marked out.** `validateEvent` throws
  "Pick a new goalkeeper first using ALLOCATE GK, then mark this player out." Tapping the GK
  chip should not open this panel at all — show the amber panel with that sentence and a
  single **ALLOCATE GK** button that goes straight to the GK picker. Never a thrown toast.
- **The floor is 6 players** (`MIN_SQUAD`, deliberately below the pre-game minimum of 7 so an
  injury is always recordable). At 6, the chip is tappable but the panel states the block.

---

## 3d — "When did this happen?"

The safety-critical prompt, promoted out of a modal-on-a-modal into **a screen of its own**.

**Hard constraint, unchanged:** the substitution flow must keep asking when the change
happened whenever the clock is not actively timing the current period. That question is the
entire fix for the bug that left one player on 25 minutes and another on 50. Nothing in this
design may remove it, shortcut it, or default it silently.

- **Amber header**, inheriting the 2a rule — the chrome states *why* it is asking before the
  coach reads a word. Sub-line: `P3 · 1ST HALF · CLOCK NOT RUNNING`.
- Question at 52 px: "How far into this period did it happen?"
- **The bar carries the argument.** One 96 px bar split at the entered minute: navy solid
  left = `4 min played / LOCKED — CAN'T CHANGE`, white outline right = `4 min left / THIS
  EDIT APPLIES HERE`, with 17 / 21 / 25 min labels beneath. This is the visual form of
  `splitSegment` and it is why the answer matters.
- **108 px −/+ 1 MIN steppers** flanking a 72 px minute readout.
- Three plain-English shortcuts: `Right at the start` / `Halfway` / `Nearly the whole period`.
  "Halfway" is what a coach actually knows.
- **IF YOU GET THIS WRONG** — amber panel: everyone's minutes shift by the amount you are out
  by; say four if unsure; it can be corrected from the season screen afterwards. A prompt
  that cannot be answered confidently gets dismissed carelessly, which is the same bug
  wearing a hat.
- `Cancel the change` / `4 MINUTES IN — CARRY ON →`.

Wire to the existing `elapsedMinutes` in `replanFromRosterChange`. Note `splitSegment`
requires `1 ≤ elapsed < duration`; clamp at the edges rather than disabling the steppers, so
the control never feels stuck.

---

## 4a — Honours (replaces 2c)

**The bug:** "NEVER HAD EITHER — PICK FROM HERE" is only true for the first few rounds. On
the real 11-game season every player has an honour, so the green block — the centrepiece of
the screen — renders empty.

**The fix is to change the question, not to add an empty state.** The block now asks *who has
gone longest without one*:

- Label: `LONGEST WITHOUT ONE — PICK FROM HERE`, sub-line "Playing today, furthest back first."
- Four chips, each with the player's name and the reason underneath: `NEVER HAD ONE` or
  `9 ROUNDS AGO`.
- Never-honoured players sort to the top on their own, because "never" is longer than any
  number of rounds. The screen therefore works identically in round 1 (everyone is "never")
  and round 30.
- Below: `EVERYONE ELSE`, same rows as today, sorted most-overdue-first, absent players
  dashed and dimmed at the bottom.

Sort key — `lastRound` is already computed in `TeamSheetView`:

```js
// 0 = never honoured, so it sorts first. Today's squad before absentees.
const overdueOrder = (a, b) =>
  (squad.has(b) - squad.has(a)) ||
  ((honours[a].lastRound ?? 0) - (honours[b].lastRound ?? 0)) ||
  a.localeCompare(b);

const dueNext = players.sort(overdueOrder).slice(0, 4);
const reason = (p) =>
  honours[p].lastRound == null ? 'NEVER HAD ONE'
  : seasonGames.length - honours[p].lastRound === 0 ? 'LAST ROUND'
  : `${seasonGames.length - honours[p].lastRound} ROUNDS AGO`;
```

The same reframing applies to the save modal's chip rows (2d): lead with longest-since, not
never-had. The "Everyone else ▾" expander stays.

---

## 4b — Landscape

1366 × 1024. Landscape is not a squashed portrait.

- **The pitch turns with the iPad.** Portrait uses a 100 × 148 viewBox; landscape uses
  148 × 100, goals left and right, halfway line vertical. The pitch on screen must match the
  pitch in front of the coach, or the position colours stop meaning anything.
- **Header 88 px** (down from 96), same contents, same amber rule.
- **Pip strip 40 px rows** — unchanged otherwise.
- **The action stack unstacks into a row** under the pitch: GOAL (weighted 1.4) · SQUAD ·
  HONOURS · SEASON · SAVE, 76 px tall.
- **The bench rail keeps its 400 px width.** It is the one column whose job is reading, and
  reading width should not change with orientation. Card contents are identical to portrait,
  including the two answers and the wristband swatch.
- The persistent red sub bar sits between the pitch and the action row, full width of the
  pitch column — still not dismissible, still `DONE ✓` to acknowledge.
- Fairness summary pins to the bottom of the rail where the queue runs out.

Implementation note: this is a layout branch, not a second component. Everything inside is
the same parts at the same sizes; only the flex direction of the main region, the pitch
viewBox, and the action stack change.

---

## Accessibility pass

Low urgency — one coach, one iPad — but cheap, and it makes the pitch usable with VoiceOver
if a parent ever helps out.

- Pitch tokens (`PlayerToken.jsx`) and bench rail cards are `div`s with tap handlers. Make
  them `<button type="button">` with `background: none; border: 0; font: inherit;` added to
  the existing style objects. No visual change.
- Give each token an `aria-label` that reads as speech, not as data:
  `"Ellery, right back, white wristband, coming off in 1 minute 42"`.
- The persistent sub bar should be `role="status"` `aria-live="polite"` so it announces once
  when it appears — not `assertive`, which would interrupt.
- The amber header state needs a text equivalent, not colour alone: the sub-line already
  says `CLOCK NOT RUNNING`. Keep that string whenever the header is amber.
- Minimum hit target 44 px is met everywhere except the HT pip (40–42 px). Leave it — it is
  a label, not a control.

---

## Things deliberately not designed

- **Sub-9 lineups.** `replan.js` leaves a position `null` when the bench is empty. The pitch
  will render a hole. Worth a designed empty token, but it needs a real occurrence to design
  against.
- **The `Show the kids` landscape view itself.** It exists and works; it was out of scope.
  When it is revisited, note that 4b makes the main screen landscape too, so the two need to
  be told apart at a glance.
- **Match notes in the season history.** Notes save with the game and appear in history, but
  the history entry was never designed.
