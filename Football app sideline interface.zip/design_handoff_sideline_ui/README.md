# Handoff: Sideline UI redesign (MiniRoos Sub Planner)

## Overview

The app is a 9v9 junior football (MiniRoos) rolling-sub planner used **on the sideline, on an iPad in portrait, in direct sunlight, while the coach is also watching the game**. It works, but the interface fails in two specific ways the coach reported:

1. **Subs get missed** — the sub cue is a transient badge/modal that passes while the coach is watching play.
2. **The clock gets left un-started or un-paused** — the clock is a small button in the header and its state is easy to miss.

Two questions are also asked constantly by the players and the assistant coach:

- *"Who am I going on for?"*
- *"When am I going back on?"*

This redesign addresses all four. It keeps the existing navy/light-blue palette and — critically — keeps the **player position colours exactly as they are**, because they map to physical wristbands the kids wear (black = left, grey = centre, white = right, magenta = goalkeeper). Nothing in the chrome may compete with those four colours.

Scope of this handoff:

| Screen | Target file in the repo |
|---|---|
| 2a Live game | `src/components/TeamSheetView.jsx` (+ `FieldView.jsx`, `PlayerToken.jsx`) |
| 2b Player answer sheet | `src/components/TeamSheetView.jsx` (replaces the "Fat-Finger Bottom Panel") |
| 2c Honours | `src/components/TeamSheetView.jsx` (honours sheet) |
| 2d Post-game save | `src/components/TeamSheetView.jsx` (save modal) |
| 2e Season tracker | `src/components/SeasonView.jsx` |

`InputView.jsx` (Match Setup) is **not** part of this redesign and should be left alone for now.

## About the design files

`Sideline UI.dc.html` in this bundle is a **design reference created in HTML** — a static prototype showing the intended look, hierarchy and behaviour. It is **not production code to copy**. The task is to recreate these designs inside the existing app: React 18 + Vite, function components, **inline style objects** (this codebase does not use CSS classes or a CSS framework), state in `TeamSheetView`/`App`, constants in `src/constants.js`.

The file contains three stacked sections. Read from the top:

- **TURN 2** — the approved design (`2a`–`2e`). This is what to build.
- **TURN 1** — three earlier explorations (`1a`, `1b`, `1c`). Reference only; do not build.
- **CURRENT APP — RECREATED FROM SOURCE** — a faithful rebuild of today's UI, for before/after comparison.

Every frame is drawn at **1024 × 1366 px = iPad portrait at 1× CSS pixels**. All sizes in this document are CSS px at that viewport.

## Fidelity

**High-fidelity.** Colours, type sizes, weights, borders, radii and copy are final and should be matched. Layout structure (flex directions, fixed vs flexible tracks) is also final. Micro-interactions not shown as separate frames are specified in prose below.

---

## Design tokens

Replace the current ad-hoc palette with this set. Suggested home: extend `src/constants.js` with a `UI` export (the position colours already live there — leave `POS_BG` / `POS_TEXT` / `POS_BORDER` untouched).

### Colour — chrome

| Token | Hex | Use |
|---|---|---|
| `navy` | `#0f2d5a` | Header bars, primary buttons, all heavy borders, primary text |
| `blueLine` | `#c7daf7` | 2px hairlines, inactive borders, dividers |
| `page` | `#f0f6ff` | Screen background |
| `track` | `#e2ecfc` | Bar-chart tracks, inactive pip fills |
| `bodyText` | `#4a6b8a` | Secondary text |
| `label` | `#7a96b0` | All-caps section labels, tertiary text |
| `onNavyMuted` | `#a8c6ee` | Secondary text **on** navy |
| `onNavyBorder` | `#5e8ecd` | Outlined button borders **on** navy |
| `backdrop` | `#143a6b` | Modal backdrop (opaque in the mock; ship as `rgba(15,45,90,0.92)`) |
| `white` | `#ffffff` | Cards |

### Colour — status (the only non-navy accents allowed)

| Token | Hex | Meaning |
|---|---|---|
| `go` | `#0b7a3b` | Clock running, player coming ON, save |
| `goTint` | `#e8f3ec` | Green card fill |
| `goOnDark` | `#bee0cb` | Text on `go` |
| `stop` | `#c62828` | Sub imminent, player coming OFF, fairness outlier |
| `stopOnDark` | `#f3c1c1` | Text on `stop` |
| `warn` | `#b25e00` | Clock NOT running, data mismatch |
| `warnTint` | `#fdf1e3` | Amber card fill |
| `warnText` | `#7a4100` | Text on `warnTint` |

**Rule:** no other colours. The current build uses ~8 competing hues (`#1d6fcf`, `#059669`, `#f59e0b`, `#dc2626`, `#7c3aed`, `#d97706`, `#b45309`…). Collapsing to navy + three status colours is what makes the wristband colours legible in sun.

### Colour — player wristbands (DO NOT CHANGE)

Already correct in `src/constants.js`:

```
GK  #d946ef  (magenta)   text #0f2d5a
LB/LM/LF  #111827 (black) text #ffffff
CB/CM     #b0bec5 (grey)  text #111827
RB/RM/RF  #ffffff (white) text #111827
```

One change only: token **borders** become `5px solid #0f2d5a` (navy) instead of the current inverted per-position border, **except** when the player is involved in the next change, where the border becomes `5px solid #c62828`. Navy borders read as a consistent outline in sun and stop the white/grey tokens dissolving into the pitch.

### Typography

Single family: **Archivo** (Google Fonts, weights 400/500/700/800/900). Fall back to `system-ui, sans-serif`. Numbers always `font-variant-numeric: tabular-nums`.

| Role | Size / weight | Notes |
|---|---|---|
| Clock (header) | 58px / 800, `letter-spacing: -2px` | tabular |
| Clock (player sheet) | 96px / 800, `letter-spacing: -3px` | tabular |
| Player name (sheet) | 78px / 800, `letter-spacing: -2px` | |
| Screen title | 44–46px / 800, `letter-spacing: -1px` | |
| Bench card name | 31px / 800 | |
| Season list name | 27px / 800 | |
| Token name | 27px / 800 | |
| Token position code | 19px / 900 | |
| Big button label | 21–26px / 900 | |
| Tool button label | 17px / 900, `letter-spacing: 0.5px` | |
| Body | 18–24px / 700 | |
| Section label | 15–18px / 900, `letter-spacing: 2px`, all caps, `label` colour | |

**Minimum on-screen size is 15px** and that's only for all-caps labels. Nothing smaller — the current build has 11px and 12px labels that are unreadable at arm's length in sun.

### Spacing, radius, borders

- Spacing steps: 8 / 9 / 10 / 11 / 14 / 16 / 18 / 22 / 26 / 30 / 34
- Radius: 10 (pips, small buttons) · 12 (list rows, tool buttons) · 14 (cards, sliders) · 16–18 (large cards) · 24 (modals) · 28 (bottom sheet top corners) · 50% (tokens)
- Borders: `2px` hairline `blueLine` · `3px` secondary emphasis · `4px` primary emphasis (navy or status) · `5px` player tokens · `8px` bottom-sheet top edge
- No shadows anywhere in the live game screen. Flat only — shadows cost contrast in sun. (Frame shadows in the mock are canvas presentation, not part of the design.)
- **Minimum touch target 88px** for any button used during a game.

---

## Screen 2a — Live game

Replaces the current `TeamSheetView` layout (header / timeline / bench-panel + pitch / footer).

### Layout

Root: `min-height: 100vh; background: page; display: flex; flex-direction: column;`

| Band | Height | Notes |
|---|---|---|
| Header | `96px` fixed | navy, `padding: 0 22px` |
| Period pips | auto (~66px) | white, `padding: 11px 16px`, `border-bottom: 2px blueLine` |
| Body | `flex: 1; min-height: 0` | `display: flex; gap: 14px; padding: 14px 16px` |
| Action stack | auto | `padding: 0 16px 14px; display: flex; flex-direction: column; gap: 10px` |

### Header (navy)

- Left: clock `58px/800` white tabular, then status caption `17px/900` in `onNavyMuted`, `letter-spacing: 2px`, `white-space: nowrap` — `"P3 · 1ST HALF · RUNNING"`.
- Right: score `21px/800` white (`"Kenmore 2 – 1"`), then the clock cluster: `−1 MIN`, the clock button, `+1 MIN`.
- **Clock nudge buttons:** `64 × 64px; border: 2px solid onNavyBorder; border-radius: 10px`, stacked glyph (`−` / `+`, `28px/800`, white) over caption (`1 MIN`, `13px/800`, `letter-spacing: 1px`, `onNavyMuted`). Wire to the existing `nudgeClock(∓60)` — this replaces the "+1m to Clock" / "-1m from Clock" pair currently buried in the clock dropdown menu. The clock counts **down**, so `+1 MIN` (add a minute of remaining time) is `nudgeClock(-60)` and `−1 MIN` is `nudgeClock(+60)` — the existing handler mapping is correct, keep it.
- **Clock button, running:** `background: go; border-radius: 10px; padding: 12px 24px; font: 900 21px;` white, label `"▮▮ PAUSE"`.
- **Clock button, NOT running:** the whole header turns `warn` (`#b25e00`); caption becomes `"PERIOD 4 · SECOND HALF · NOT STARTED"` in `#f6ddbe`; the clock reads the period length (`09:00`); the button becomes `background: #fff; color: navy; padding: 22px 40px; font: 900 34px;` label `"▶ START"`, with `"Clock is not running / Tap when the referee restarts"` beside it at 21px/17px. See frame `1b` in the reference file for this state.

This is the fix for the forgotten clock: the amber header is not dismissible and not subtle. It persists until the clock is started.

### Period pips

`display: flex; gap: 8px; align-items: center`. One pip per segment from `segments[]`, height `44px`, radius `10px`, `font: 800 17px`.

| State | Style |
|---|---|
| Done (`locked`) | `background: track; color: label` — label `"P1 ✓"` |
| Current | `background: navy; color: #fff; font-weight: 900; flex: 1.2` — `"P3 · NOW"` |
| Next, ≤2 min away | `background: #fff; border: 3px solid stop; color: stop; font-weight: 900` — `"P4 · 1:42"` |
| Future | `background: page; border: 2px solid blueLine; color: label` — `"P5"` |
| Half-time marker | fixed `width: 42px`, `font-size: 14px`, `"HT"`, future styling |

Tapping a pip selects that segment for viewing/editing (current behaviour of the timeline row — keep it).

### Pitch (left, flexible)

Wrap in `flex: 1; display: flex; flex-direction: column; min-width: 0; min-height: 0`.

**Important implementation note:** the current `FieldView` sizes the pitch with `padding-bottom: 148%`, which is driven by *width* and therefore overflows the available height on this layout. Size it from height instead:

```js
{ position: 'relative', flex: 1, minHeight: 0,
  aspectRatio: '100 / 148', width: 'auto', maxWidth: '100%', margin: '0 auto',
  background: '#2f7d3c', borderRadius: 16, overflow: 'hidden',
  border: '3px solid #0f2d5a' }
```

Pitch fill is flat `#2f7d3c` — drop the current 5-stop gradient (it reduces token contrast). Keep `FieldSVG` markings but simplify to: outline, halfway line, centre circle, two penalty boxes, two goals, at `rgba(255,255,255,0.8)` / `0.55`.

Tokens: keep `FIELD_LAYOUT` percentages and `translate(-50%,-50%)` exactly as they are. Token size `124px` (`calcSize` may stay, but raise the cap to 124 and the floor to 96). Name `27px/800`, position code `19px/900`, no shadow.

**Players in the next change** get `border: 5px solid stop` and a badge below the token, overlapping by `-13px`: `background: stop; color: #fff; border-radius: 7px; padding: 2px 10px; font: 900 17px; white-space: nowrap` reading `"▼ OFF 1:42"` (live countdown). Drop the current dashed-red ring and the `"▲ IN: name"` badge — the incoming player is named in the rail instead, so the pitch stays readable.

Tapping a token opens screen **2b**.

### Bench rail (right, `width: 322px`, `flex-shrink: 0`)

`display: flex; flex-direction: column; gap: 11px; min-height: 0`.

1. **NEXT CHANGE header** — `background: stop; border-radius: 12px; padding: 10px 14px; display: flex; justify-content: space-between; align-items: baseline`. Left `"NEXT CHANGE"` `24px/900` white; right the live countdown `"1:42"` `24px/900` white tabular.

2. **Incoming player cards** (one per sub at the next boundary) — `background: #fff; border: 4px solid navy; border-radius: 14px; padding: 13px 15px`. Inside, a row with `gap: 12px`:
   - Wristband swatch: `width: 16px; height: 52px; border-radius: 4px`, filled with that player's **destination position colour**. For white, use `background: #fff; box-shadow: inset 0 0 0 2px navy` so it's visible on white.
   - Name `31px/800` navy, `line-height: 1.1`.
   - Second line `18px/700` in `go`: **`"▲ ON for Ellery · RB"`**.

   That single line is the answer to *"who am I going on for?"* and it must never be truncated or abbreviated.

3. **`WAITING`** label, then the same card for bench players not in the next change, with `border: 2px solid blueLine` and the second line in `label`: `"▲ ON at 33′ for Grace · CM"`.

4. **`BACK ON`** label, then one card `border: 2px solid blueLine; padding: 12px 15px`, containing a row per player currently coming off, `justify-content: space-between`: name `22px/800` navy, and `"41′ · RB"` `19px/700` in `bodyText`.

   That is the answer to *"when am I going back on?"* — derived from the schedule, not entered by hand.

5. Flexible spacer, then **MINUTES** card: `border: 2px solid blueLine; border-radius: 14px; padding: 12px 15px`. Header row: `"MINUTES"` label + spread (`"21–29m"`) `15px/800`. Below, a 12-bar chart, `height: 50px`, `gap: 4px`, bars `flex: 1; border-radius: 3px 3px 0 0`, sorted descending, `background: navy`; the two lowest `#7a96b0`; the single lowest `stop`.

### Action stack

1. **Slide-to-confirm sub** — `background: #fff; border: 3px solid navy; border-radius: 14px; padding: 8px; display: flex; align-items: center; gap: 14px`. Thumb: `width: 92px; height: 62px; background: navy; border-radius: 10px`, `"›››"` 28px white. Label `"Slide to make the sub now"` `24px/800` navy.
   - Drag the thumb to the right edge to commit; releasing before ~70% springs back. No dialog. On commit: advance the segment, log the change, show the toast.
   - Rationale: this replaces the mid-game confirm dialogs. Nothing should ever cover the pitch during play.
2. **Tool row** — 6 equal buttons, `gap: 9px`, `height: 88px`, `border-radius: 12px`, each a stacked icon (25px) + label (17px/900). First (`⚽ GOAL`) is filled `navy`/white; the other five are `#fff` with `border: 3px solid navy`, navy label: `🧤 GK`, `👥 SQUAD`, `🏆 HONOURS`, `📅 SEASON`, `💾 SAVE`.
   - `SQUAD` opens a single sheet containing late-arrival and player-out (currently two separate buttons + two modals).
   - `HONOURS` → 2c, `SEASON` → 2e, `SAVE` → 2d. These are currently buried; the coach uses Honours mid-game, so it must be reachable in one tap.

### Locked / completed periods

Keep the existing lock semantics. When a past segment is selected, replace the slide-to-confirm bar with `"🔒 This period is finished"` — `padding: 20px; text-align: center; font: 800 21px; color: label; background: #fff; border: 2px dashed blueLine; border-radius: 14px`.

---

## Screen 2b — Player answer sheet

Replaces the current bottom "Fat-Finger Panel". Opens on any token or bench-card tap. Backdrop: the rest of the screen dims (`rgba(15,45,90,0.35)`); tapping outside closes.

Sheet: `position: fixed; left/right/bottom: 0; background: #fff; border-top: 8px solid navy; border-radius: 28px 28px 0 0; padding: 30px 32px 34px`.

1. **Identity row** (`justify-content: space-between; margin-bottom: 26px`):
   - `116px` circular token in the player's wristband colour, `border: 6px solid navy`, showing position code `19px/900` and the wristband colour name (`"white"`) `22px/800`. Naming the colour out loud is deliberate — it's how the kids identify themselves.
   - Name `78px/800` navy; below, `24px/700` in `bodyText`: `"Right back · white wristband · 26 min played"`.
   - `Close ✕` button: `border: 3px solid blueLine; border-radius: 12px; padding: 16px 26px; font: 800 24px; color: bodyText`.

2. **The two answers** — two equal cards, `gap: 16px; border-radius: 18px; padding: 24px 26px`:
   - Left, `background: stop`: label `"YOU COME OFF IN"` `21px/900` in `stopOnDark`, `letter-spacing: 2px`; value `"1:42"` `96px/800` white tabular; caption `"Maddy is coming on for you"` `24px/700` in `stopOnDark`.
   - Right, `background: go`: `"YOU GO BACK ON AT"` / `"41′"` / `"Right back again · 9 min on the bench"`, same scale, `goOnDark` for label and caption.
   - For a **bench** player the cards invert: left becomes `go` `"YOU GO ON IN"`, right becomes navy `"YOU CAME OFF AT"`. For a player with no scheduled change, the right card is `background: page; color: bodyText` reading `"ON FOR THE REST OF THE HALF"`.

3. **Goals / assists** — two cards `border: 3px solid blueLine; border-radius: 16px; padding: 16px 20px`, each `justify-content: space-between`: label `24px/900` navy (`⚽ GOALS`, `👟 ASSISTS`); then `−` (`64px` square, `border: 3px solid blueLine`, `36px/800` `bodyText`), value `46px/800` navy, `+` (`64px` square, `background: navy`, white `36px/800`).

4. **Coach actions** — three equal buttons, `border: 3px solid navy; border-radius: 16px; padding: 20px; font: 900 22px` navy: `🔀 MOVE POSITION`, `🧤 PUT IN GOAL`, `➖ MARK OUT`. Hide this row in a "kids/presentation" mode so a player can't tap them.

---

## Screen 2c — Honours

Rebuild of the honours sheet. Backdrop `backdrop`, `padding: 40px`, `box-sizing: border-box`. Card: `background: #fff; border-radius: 24px; padding: 34px 36px 30px`.

- Title `"🏆 Season Honours"` `44px/800` navy + `Close ✕` (as 2b).
- Sub-line `20px/600` `bodyText`: `"7 games · ⭐ Player of the Week · 🏅 Captain"`.
- **`NEVER HAD EITHER — PICK FROM HERE`** block — `background: goTint; border: 4px solid go; border-radius: 16px; padding: 20px 24px`; label `18px/900` in `go`, `letter-spacing: 2px`; then wrapping chips `background: #fff; border: 3px solid go; border-radius: 12px; padding: 14px 22px; font: 800 30px` navy. **Today's squad only.**
  - This is the change that matters: the current list is alphabetical and gives no answer. Sort by "no honours, then longest since last honour". Selecting a chip pre-fills 2d.
- **`ALREADY HONOURED`** — rows `padding: 16px 20px; border: 2px solid blueLine; border-radius: 12px`: name `30px/800` navy; right side `gap: 18px; font: 800 24px` `bodyText` showing `⭐ ×2`, `🏅 ×1`, `last: R7`. Zero counts render as `⭐ —` in `#a8c0d8`. Players not in today's squad: `border: 2px dashed blueLine; opacity: 0.55` and `"not playing today"`.

Data: derive from `seasonGames[].potm` / `.captain`; add "rounds since last honour" (index of the most recent game where the player was `potm` or `captain`).

---

## Screen 2d — Post-game save

Same fields and same `onSave` payload as today. Structural changes only.

Backdrop and card as 2c. Title `"📊 Post-game summary"` `44px/800`.

- Section labels throughout: `17px/900; letter-spacing: 2px; color: label`.
- **MATCH LABEL** — input `border: 3px solid blueLine; border-radius: 12px; padding: 18px 20px; font: 700 24px` navy.
- **SCORE** — two number inputs, `gap: 18px`, with a `34px/800` `#7a96b0` en dash between. `US` has `border: 4px solid navy`, `THEM` `border: 3px solid blueLine`; both `border-radius: 14px; padding: 18px; font: 800 52px; text-align: center`. Column captions `16px/800` `label`.
- **Mismatch warning** — sits *directly under the score*, not at the bottom: `background: warnTint; border: 3px solid warn; border-radius: 12px; padding: 16px 20px; font: 700 20px; color: warnText`, text `"⚠️ 2 goals allocated to players but the score says 3. Tap a player to allocate the third — or save now and fix it later."`
- **⭐ PLAYER OF THE WEEK** and **🏅 CAPTAIN NEXT WEEK** — replace both `<select>`s with chip rows: eligible ("never had one") names first as `border: 3px solid blueLine; border-radius: 12px; padding: 14px 24px; font: 800 26px` navy; selected chip becomes `background: navy; color: #fff` with a `✓`; a final `"Everyone else ▾"` chip in `label` colour expands the full squad. Helper line under each: `18px/700` — `go` for `"Never had one · scored today"`, `bodyText` for `"Grace captained the last win"`.
- Footer: `Cancel` (`flex: 1; border: 3px solid blueLine; border-radius: 14px; padding: 24px; font: 800 24px; color: bodyText`) and `💾 SAVE GAME` (`flex: 2; background: go; border-radius: 14px; padding: 24px; font: 900 26px` white).

Keep the existing behaviour: save, then navigate to the season view.

---

## Screen 2e — Season tracker

Rebuild of `SeasonView`. The 11-column table is the problem — it can't be read on a phone or in sun. Replace it with one sorted list.

Root `display: flex; flex-direction: column; background: page`.

1. **Header** (navy, `padding: 22px 26px 20px`, `flex-shrink: 0`): top row has `← Back to game` and `📤 Export` / `📥 Import` as outlined buttons — `border: 2px solid onNavyBorder; border-radius: 10px; padding: 12px 22px; font: 800 20px` white. Then `"Season 2026"` `46px/800` white; then a baseline row `gap: 20px`: `"7 games"` (`24px/700` `onNavyMuted`), `"4 W · 1 D · 2 L"` (`24px/800` white), `"18 goals for · 12 against"` (`onNavyMuted`).
   - "Reset Season" moves out of the header into the Matches tab behind a confirm — it's currently one tap from a destructive wipe.
2. **Tabs** (white, `padding: 14px 20px`, `border-bottom: 2px solid blueLine`, `gap: 10px`): `FAIRNESS` (active: `background: navy; color: #fff; font-weight: 900`), `MATCHES`, `HONOURS`, `GOALS` (inactive: `border: 2px solid blueLine; color: bodyText; font-weight: 800`); all `border-radius: 10px; padding: 14px 28px; font-size: 22px`.
3. **Body** `flex: 1; min-height: 0; padding: 20px 20px 8px; display: flex; flex-direction: column; overflow: hidden`:
   - Header row: `"AVERAGE MINUTES PER GAME"` label + `"Spread 34–42m · target 38m"` `18px/800` `bodyText`.
   - One row per player, `gap: 9px`, each `background: #fff; border: 2px solid blueLine; border-radius: 12px; padding: 9px 16px; display: flex; align-items: center; gap: 16px`:
     - wristband swatch `14 × 34px; border-radius: 4px` (their most-played position's colour; white gets `inset 0 0 0 2px blueLine`)
     - name, fixed `width: 150px`, `27px/800` navy
     - bar track `flex: 1; height: 26px; background: track; border-radius: 5px`, fill `background: navy` at `avg / maxAvg`
     - minutes, fixed `width: 74px; text-align: right; 25px/800` navy
     - meta, fixed `width: 134px; text-align: right; white-space: nowrap; 17px/700` `label` — `"7 games · GK ×2"`
     - The **lowest** player: `border: 4px solid stop`, bar fill `stop`, minutes and meta in `stop`, meta reads `"lowest · 3 games"`.
   - Sort descending by average minutes.
4. **Footer** — a sibling of the body (not inside it, or it gets clipped): `flex-shrink: 0; margin: 0 20px 18px; background: #fff; border: 2px solid blueLine; border-radius: 12px; padding: 14px 18px; justify-content: space-between; gap: 16px`. Left `20px/700` `bodyText`: `"Next game the planner will start Noa, Maddy and Lyla to close the gap."` (generated from the fairness oracle in `scheduler.js` — name the three players the next `orderPlayersForGame` call would start). Right: `NEW MATCH →` `background: navy; border-radius: 10px; padding: 14px 24px; font: 900 20px` white, `white-space: nowrap`.

The remaining data from the old table (bench minutes, GK H1/H2 splits, goals, assists, POTM, captain, top positions) moves to the other three tabs and to a per-player expansion — nothing is deleted, only re-homed.

---

## Interactions & behaviour

| Trigger | Behaviour |
|---|---|
| Clock not running | Header goes `warn` and stays. No timeout, no dismiss. |
| Tap header clock button | Start / pause. Keep the existing `startCurrentPeriod` / `pauseCurrentPeriod` and the wake-lock + audio-unlock calls on start. |
| Clock ≤ 2:00 to a boundary | `NEXT CHANGE` header + the affected pips and tokens go `stop`; countdown ticks in the rail, on the pips and on the token badges. |
| Clock ≤ 0:30 | Keep the existing 5-second buzz. Do **not** add flashing — the coach asked for calm alerts. |
| Boundary reached | Keep the auto-advance and the end-of-period buzz. Replace the full-screen "Period N started, call these subs" modal with a persistent state: the slide-to-confirm bar turns `stop` and reads `"Slide to confirm — Maddy ▶ RB, Lyla ▶ LM"` until slid. That is the missed-sub fix — the cue does not disappear on its own. |
| Slide-to-confirm released past ~70% | Commit; bar returns to normal; toast `"Subs made ✓"`. Below 70%, spring back. |
| Tap token or bench card | Open 2b. Backdrop tap or `Close ✕` dismisses. |
| Tap a past pip | Show that segment read-only with the lock message. |
| Long-press a bench card | Optional shortcut: bring that player on now (routes through the existing emergency-sub split). |

Transitions: `120ms ease-out` on button press (`transform: scale(0.97)`), `180ms` on the sheet slide-up, none on colour state changes — instant is easier to notice from three metres away. Nothing pulses or animates continuously; it drains battery and pulls the eye off the game.

Accessibility / field conditions: minimum contrast 7:1 for all text; no colour-only meaning (every status colour is paired with a word or a `▲` / `▼` glyph); minimum 88px targets during play; the design assumes wet fingers and no hover.

## State management

No new state is required — everything is derivable from what `App.jsx` and `TeamSheetView.jsx` already hold.

- `gameClock` (existing) drives the header, the countdowns and the ≤2:00 / ≤0:30 states.
- `segments` (existing) drives the pips, the pitch, and the rail. `getSubChanges(segments[i], segments[i+1])` already produces the `{on, off, pos}` triples the `NEXT CHANGE` cards need — **that data exists today and is simply not being shown as text**.
- *"When am I going back on?"* — walk forward from the current segment to the first one where the player appears in `assignment`, and sum `duration` up to it. Add a helper in `scheduler.js`: `nextAppearance(segments, fromSegIdx, playerName) → { minute, pos } | null`.
- `calcStats` (existing) gives `minutesMap` for the MINUTES chart and the season list.
- New UI state, all local to `TeamSheetView`: `slideProgress` (number, 0–1), `subConfirmed` (boolean, resets on each boundary), `activeTab` in the season view.
- Existing modal state for late player / player out / GK / save / honours stays, minus the modals removed above.

## Assets

None. No images, no icon files. The emoji used (⚽ 🧤 👥 🏆 📅 💾 🔀 ➖ 👟 ⭐ 🏅 ▮▮ ▶ ▲ ▼ ›››) render from the system font and are the same set already in the codebase. Add Archivo via `<link>` in `index.html`, or self-host if the app needs to work fully offline (it is a PWA with a service worker — self-hosting is the safer choice).

## Files in this bundle

- `Sideline UI.dc.html` — the design reference. Sections top to bottom: TURN 2 (`2a`–`2e`, build these), TURN 1 (`1a`–`1c`, explorations, reference only), CURRENT APP RECREATED (before/after comparison).
- `README.md` — this document.
- `screens/` — 1024 × 1366 PNGs of each screen: `2a-live-game`, `2b-player-answer`, `2c-honours`, `2d-save`, `2e-season`, plus `before-current-live-game` for comparison.
- `support.js` — runtime needed only to open the `.dc.html` reference locally. Not part of the app.

## Suggested build order

1. Tokens into `constants.js`; Archivo into `index.html`.
2. `TeamSheetView` header + pips (fixes the clock problem on its own).
3. `FieldView` height-driven sizing + navy token borders + `▼ OFF` badges.
4. Bench rail with the "ON for X · POS" and "BACK ON" lines (fixes both player questions).
5. Slide-to-confirm + remove the boundary modal (fixes missed subs).
6. 2b player sheet.
7. 2c honours, 2d save.
8. 2e season view.

Steps 2–5 deliver essentially all of the value; 6–8 are polish and can ship in a second pass.
